insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (3,5,2019, 1, 25, 350.67, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (2,5,2019, 2, 18, 340.6, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (1,5,2019, 3, 15, 361.55, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (7,5,2019, null, null, 370.32, 'N');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (4,1,1994, 1, 25, 340.5, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (5,1,1994, 2, 18, 332.4, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (6,1,1994, 3, 15, 333.7, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (8,1,1994, null, null, 347.6, 'N');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (3,3,2018, 1, 25, 351.67, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (2,2,2019, 1, 25, 360.54, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (1,2,2019, 2, 18, 367.56, 'Y');
insert into rezultat(vozacr, stazar, sezona, plasman, bodovi, maksbrzina, zavrsio) 
values (3,5,2005, 1, 24, 340.5, 'Y');