insert into drzava(idd, nazivd) values(1, 'Finland');
insert into drzava(idd, nazivd) values(2, 'Spain');
insert into drzava(idd, nazivd) values(3, 'Germany');
insert into drzava(idd, nazivd) values(4, 'Brazil');
insert into drzava(idd, nazivd) values(5, 'Great Britain');
insert into drzava(idd, nazivd) values(6, 'Italy');
insert into drzava(idd, nazivd) values(7, 'France');