insert into projekat values (10,100, 'Optimizacija u spicu','TE-TO');
insert into projekat values (20, 70, 'Skladistenje','FADIP');
insert into projekat values (30, 50, 'Optimizacija mreze','ElektroLux');
insert into projekat values (40, 50, 'IIS','Sintelon');
insert into projekat values (50, 70, 'Dijete','KBC');
insert into projekat values (60,100, 'Ziro racuni','Dafiscan');
insert into projekat values (70,100, 'IIS*Case','DAS');
insert into projekat values (80,100, 'Data Warehouse','Minel');
commit;